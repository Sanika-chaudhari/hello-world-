
Fraudulent Job Posting Detection - Trained Project
- model_logreg.pkl : Logistic Regression model trained on full dataset
- model_rf.pkl    : Random Forest model trained on full dataset
- vectorizer.pkl  : TF-IDF vectorizer (max_features=10000)
- app.py          : Streamlit app to demo models
- metrics_summary.csv : Performance summary on held-out test set
