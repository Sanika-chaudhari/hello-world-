import streamlit as st
import joblib, os, re, pandas as pd

st.set_page_config(page_title="Fraudulent Job Posting Detection", layout="centered")
st.title("💼 Fraudulent Job Posting Detection (Trained Models Included)")

BASE_DIR = os.path.dirname(__file__)
model_lr_path = os.path.join(BASE_DIR, "model_logreg.pkl")
model_rf_path = os.path.join(BASE_DIR, "model_rf.pkl")
vec_path = os.path.join(BASE_DIR, "vectorizer.pkl")

if not os.path.exists(model_lr_path) or not os.path.exists(model_rf_path) or not os.path.exists(vec_path):
    st.error("Model files not found. Please ensure model_logreg.pkl, model_rf.pkl and vectorizer.pkl are in this folder.")
    st.stop()

model_lr = joblib.load(model_lr_path)
model_rf = joblib.load(model_rf_path)
vectorizer = joblib.load(vec_path)

st.sidebar.header("Options")
model_choice = st.sidebar.selectbox("Choose model", ["Logistic Regression", "Random Forest"])
show_metrics = st.sidebar.checkbox("Show evaluation metrics (precomputed)")

st.write("Paste a job description below and click Predict. You can also include title/company profile/requirements in the input.")

desc = st.text_area("Job text", height=250, placeholder="Paste job title + description + requirements ...")

if st.button("Predict"):
    if not desc.strip():
        st.warning("Please provide job text.")
    else:
        X = vectorizer.transform([desc])
        model = model_lr if model_choice == "Logistic Regression" else model_rf
        pred = model.predict(X)[0]
        prob = None
        if hasattr(model, 'predict_proba'):
            prob = model.predict_proba(X)[0].max()
        label = "Fraudulent" if pred == 1 else "Real / Legitimate"
        st.markdown(f"### Prediction: **{label}**")
        if prob is not None:
            st.write(f"Confidence: {prob:.2f}")
        # Simple heuristics
        phone_found = bool(re.search(r'\b\d{10}\b', desc))
        email_found = bool(re.search(r'\S+@\S+\.\S+', desc))
        if phone_found or email_found:
            st.write("- Found phone/email in description (may be suspicious if request is unprofessional).")
        if any(w in desc.lower() for w in ['pay', 'deposit', 'fee', 'payment', 'refund']):
            st.write("- Contains payment-related words — common in scam postings.")

if show_metrics:
    st.write("Evaluation metrics (on held-out test set):")
    # metrics loaded from files if available
    metric_path = os.path.join(BASE_DIR, "metrics_summary.csv")
    if os.path.exists(metric_path):
        dfm = pd.read_csv(metric_path)
        st.dataframe(dfm.T)
    else:
        st.write("Metrics file not found. Train the models to generate metrics.")
